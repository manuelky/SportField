/* SPORTFIELD - lógica de la aplicación */
"use strict";

const STORAGE_KEY = "sportFieldReservations";

const venues = [
  {id:"SP001",name:"Arena Pádel Club",sport:"Pádel",type:"Cancha panorámica",price:65000,location:"Zona deportiva",image:"https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?w=900"},
  {id:"SP002",name:"Estadio Fútbol 5",sport:"Fútbol",type:"Sintética · 5 jugadores",price:95000,location:"Complejo deportivo",image:"https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=900"},
  {id:"SP003",name:"Cancha Basket Pro",sport:"Baloncesto",type:"Cancha cubierta",price:70000,location:"Centro deportivo",image:"https://images.unsplash.com/photo-1546519638-68e109498ffc?w=900"},
  {id:"SP004",name:"Vóley Arena",sport:"Voleibol",type:"Arena / piso deportivo",price:60000,location:"Parque deportivo",image:"https://images.unsplash.com/photo-1612872087720-bb876e2e67d1?w=900"},
  {id:"SP005",name:"Tenis Green Court",sport:"Tenis",type:"Superficie rápida",price:55000,location:"Club deportivo",image:"https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?w=900"},
  {id:"SP006",name:"Diamante Softball",sport:"Sóftbol",type:"Campo reglamentario",price:120000,location:"Unidad deportiva",image:"https://images.unsplash.com/photo-1508344928928-7165b0f1f025?w=900"},
  {id:"SP007",name:"Fútbol 11 Central",sport:"Fútbol",type:"Césped natural",price:180000,location:"Complejo deportivo",image:"https://images.unsplash.com/photo-1459865264687-595d652de67e?w=900"},
  {id:"SP008",name:"Microfútbol Indoor",sport:"Microfútbol",type:"Cancha cubierta",price:80000,location:"Coliseo deportivo",image:"https://images.unsplash.com/photo-1517466787929-bc90951d0974?w=900"},
  {id:"SP009",name:"Béisbol Academy",sport:"Béisbol",type:"Campo de entrenamiento",price:115000,location:"Academia deportiva",image:"https://images.unsplash.com/photo-1471295253337-3ceaaedca402?w=900"},
  {id:"SP010",name:"Natación Aqua",sport:"Natación",type:"Piscina semiolímpica",price:45000,location:"Centro acuático",image:"https://images.unsplash.com/photo-1530549387789-4c1017266635?w=900"}
];

function readReservations(){
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
  catch(error){ console.error("No se pudieron leer las reservas", error); return []; }
}
function saveReservations(items){ localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); }
function money(value){ return new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP",maximumFractionDigits:0}).format(value); }
function escapeHTML(value){
  return String(value).replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
}
function formatDate(value){
  return new Date(value+"T12:00:00").toLocaleDateString("es-CO",{day:"2-digit",month:"long",year:"numeric"});
}
function initMenu(){
  const toggle=document.querySelector(".menu-toggle");
  const nav=document.querySelector(".main-nav");
  if(!toggle||!nav)return;
  toggle.addEventListener("click",()=>{
    const open=nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded",String(open));
  });
}
function initCatalog(){
  const grid=document.getElementById("venue-grid");
  if(!grid)return;
  const sportSelect=document.getElementById("sport-filter");
  const search=document.getElementById("search-filter");
  const sort=document.getElementById("sort-filter");
  const count=document.getElementById("result-count");
  const sports=[...new Set(venues.map(v=>v.sport))].sort((a,b)=>a.localeCompare(b,"es"));
  sports.forEach(sport=>sportSelect.add(new Option(sport,sport)));
  const params=new URLSearchParams(location.search);
  if(params.has("deporte")) sportSelect.value=params.get("deporte");

  function render(){
    let results=venues.filter(v=>(!sportSelect.value||v.sport===sportSelect.value)&&v.name.toLowerCase().includes(search.value.toLowerCase().trim()));
    if(sort.value==="price-asc")results.sort((a,b)=>a.price-b.price);
    if(sort.value==="price-desc")results.sort((a,b)=>b.price-a.price);
    count.textContent=`${results.length} escenario${results.length===1?"":"s"} encontrado${results.length===1?"":"s"}`;
    if(!results.length){grid.innerHTML='<div class="empty-state">No encontramos escenarios con esos filtros. Intenta con otra búsqueda.</div>';return;}
    grid.innerHTML=results.map(v=>`
      <article class="venue-card">
        <div class="venue-image" style="background-image:url('${v.image}')"><span class="venue-tag">${escapeHTML(v.sport)}</span></div>
        <div class="venue-content"><h3>${escapeHTML(v.name)}</h3><p class="venue-location">⌖ ${escapeHTML(v.location)} · ${escapeHTML(v.type)}</p>
        <div class="venue-meta"><div class="venue-price">${money(v.price)} <small>/ hora</small></div>
        <a class="btn btn-primary" href="reservas.html?escenario=${encodeURIComponent(v.id)}">Reservar →</a></div></div>
      </article>`).join("");
  }
  [sportSelect,search,sort].forEach(el=>el.addEventListener("input",render));
  document.getElementById("clear-filters").addEventListener("click",()=>{sportSelect.value="";search.value="";sort.value="default";render();});
  render();
}
function initBooking(){
  const form=document.getElementById("booking-form");
  if(!form)return;
  const venueSelect=document.getElementById("booking-venue");
  const dateInput=document.getElementById("booking-date");
  const timeSelect=document.getElementById("booking-time");
  const summary=document.getElementById("booking-summary");
  const message=document.getElementById("booking-message");
  const list=document.getElementById("booking-list");
  const total=document.getElementById("booking-total");
  const today=new Date(); today.setMinutes(today.getMinutes()-today.getTimezoneOffset());
  dateInput.min=today.toISOString().slice(0,10);

  venues.forEach(v=>venueSelect.add(new Option(`${v.name} — ${money(v.price)}/hora`,v.id)));
  const params=new URLSearchParams(location.search);
  if(params.has("escenario"))venueSelect.value=params.get("escenario");

  function getVenue(){return venues.find(v=>v.id===venueSelect.value);}
  function refreshTimes(){
    const venue=getVenue(),date=dateInput.value;
    timeSelect.innerHTML='<option value="">Selecciona un horario</option>';
    if(!venue||!date){summary.innerHTML="<span>Valor por hora</span><strong>Selecciona un escenario</strong>";return;}
    summary.innerHTML=`<span>Valor por hora</span><strong>${money(venue.price)}</strong>`;
    const hours=["07:00","08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00"];
    const reservations=readReservations();
    hours.forEach(hour=>{
      const occupied=reservations.some(r=>r.venueId===venue.id&&r.date===date&&r.time===hour);
      if(!occupied)timeSelect.add(new Option(hour,hour));
    });
    if(timeSelect.options.length===1){
      timeSelect.add(new Option("No hay horarios disponibles","",{disabled:true}));
    }
  }
  function renderBookings(){
    const items=readReservations().sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
    total.textContent=`${items.length} reserva${items.length===1?"":"s"} registrada${items.length===1?"":"s"} en este dispositivo.`;
    if(!items.length){list.innerHTML='<div class="empty-state">Todavía no tienes reservas.<br>¡Encuentra un escenario y agenda tu partido!</div>';return;}
    list.innerHTML=items.map(r=>`
      <article class="booking-item">
        <div class="booking-item-top"><div><h3>${escapeHTML(r.venueName)}</h3><p>${escapeHTML(r.sport)} · ${formatDate(r.date)} · ${escapeHTML(r.time)}</p><p>${escapeHTML(r.customerName)} · ${money(r.price)}</p></div><span class="booking-code">${escapeHTML(r.code)}</span></div>
        <button class="cancel-btn" type="button" data-cancel="${escapeHTML(r.code)}">Cancelar reserva</button>
      </article>`).join("");
    list.querySelectorAll("[data-cancel]").forEach(btn=>btn.addEventListener("click",()=>{
      if(!confirm("¿Seguro que deseas cancelar esta reserva?"))return;
      saveReservations(readReservations().filter(r=>r.code!==btn.dataset.cancel));
      renderBookings();refreshTimes();
    }));
  }
  venueSelect.addEventListener("change",refreshTimes);
  dateInput.addEventListener("change",refreshTimes);
  form.addEventListener("submit",event=>{
    event.preventDefault();
    const venue=getVenue(),date=dateInput.value,time=timeSelect.value;
    if(!venue||!date||!time){message.textContent="Selecciona un escenario, una fecha y un horario disponible.";message.className="form-message error";return;}
    if(date<dateInput.min){message.textContent="La fecha debe ser hoy o posterior.";message.className="form-message error";return;}
    const reservations=readReservations();
    const conflict=reservations.some(r=>r.venueId===venue.id&&r.date===date&&r.time===time);
    if(conflict){message.textContent="Ese horario acaba de ocuparse. Selecciona otro.";message.className="form-message error";refreshTimes();return;}
    const reservation={
      code:"SF-"+Date.now().toString().slice(-8),
      venueId:venue.id,venueName:venue.name,sport:venue.sport,date,time,
      customerName:document.getElementById("customer-name").value.trim(),
      phone:document.getElementById("customer-phone").value.trim(),
      email:document.getElementById("customer-email").value.trim(),
      price:venue.price,createdAt:new Date().toISOString()
    };
    reservations.push(reservation);saveReservations(reservations);
    form.reset();dateInput.min=today.toISOString().slice(0,10);
    message.textContent=`¡Reserva registrada! Tu código es ${reservation.code}.`;
    message.className="form-message";
    refreshTimes();renderBookings();
  });
  refreshTimes();renderBookings();
}
function initContact(){
  const form=document.getElementById("contact-form");
  if(!form)return;
  form.addEventListener("submit",event=>{
    event.preventDefault();
    const feedback=document.getElementById("contact-feedback");
    feedback.textContent="¡Formulario validado! En esta versión de demostración el mensaje no se envía a un servidor.";
    feedback.className="form-message";
    form.reset();
  });
}
function initFeatured(){
  const grid=document.getElementById("featured-grid");
  if(!grid)return;
  grid.innerHTML=["SP001","SP002","SP003"].map(id=>venues.find(v=>v.id===id)).map(v=>`
    <article class="venue-card">
      <div class="venue-image" style="background-image:url('${v.image}')"><span class="venue-tag">${escapeHTML(v.sport)}</span></div>
      <div class="venue-content"><h3>${escapeHTML(v.name)}</h3><p class="venue-location">⌖ ${escapeHTML(v.location)} · ${escapeHTML(v.type)}</p>
      <div class="venue-meta"><div class="venue-price">${money(v.price)} <small>/ hora</small></div>
      <a class="btn btn-primary" href="reservas.html?escenario=${encodeURIComponent(v.id)}">Reservar →</a></div></div>
    </article>`).join("");
}
document.addEventListener("DOMContentLoaded",()=>{initMenu();initCatalog();initBooking();initContact();initFeatured();});
